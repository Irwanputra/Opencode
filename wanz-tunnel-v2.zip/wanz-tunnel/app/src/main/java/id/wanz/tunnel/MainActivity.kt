package id.wanz.tunnel

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File

private val BG = 0xFF101C2E.toInt()
private val CARD = 0xFF182A44.toInt()
private val FIELD = 0xFF213A5C.toInt()
private val MUTED = 0xFF8FA3BF.toInt()
private val AMBER = 0xFFF6B352.toInt()
private val TEAL = 0xFF4FD1C5.toInt()
private val CORAL = 0xFFFF7A6B.toInt()

class MainActivity : Activity() {
    private val fields = LinkedHashMap<String, EditText>()
    private lateinit var btn: TextView
    private lateinit var info: TextView
    private lateinit var profileSpinner: Spinner
    private lateinit var profileAdapter: ArrayAdapter<String>
    private lateinit var modeSwitch: Switch
    private lateinit var transportSpinner: Spinner
    private lateinit var strictSwitch: Switch

    private lateinit var store: ProfileStore
    private var profiles = mutableListOf<Profile>()
    private var activeIndex = 0
    private var loading = false
    private var pendingProfileId = -1L

    private val transportKeys = listOf("ssh", "tls", "ws", "wss")
    private val transportLabels = listOf(
        "SSH langsung", "TLS / SNI", "WebSocket (WS)", "WebSocket + TLS (WSS)"
    )

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, radius: Int, ring: Int = 0, oval: Boolean = false) =
        GradientDrawable().apply {
            if (oval) setShape(GradientDrawable.OVAL) else cornerRadius = dp(radius).toFloat()
            setColor(color)
            if (ring != 0) setStroke(dp(3), ring)
        }

    private fun lp(top: Int) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }

    private fun field(
        k: String,
        hint: String,
        type: Int = InputType.TYPE_CLASS_TEXT,
        lines: Int = 1
    ) = EditText(this).apply {
        this.hint = hint
        inputType = if (lines > 1) type or InputType.TYPE_TEXT_FLAG_MULTI_LINE else type
        if (lines > 1) {
            minLines = lines
            gravity = Gravity.TOP
        }
        setTextColor(-1)
        setHintTextColor(MUTED)
        textSize = 15f
        background = shape(FIELD, 14)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        fields[k] = this
    }

    private fun text(k: String): String = fields[k]?.text?.toString()?.trim() ?: ""

    private fun section(title: String) = TextView(this).apply {
        text = title
        textSize = 13f
        setTextColor(AMBER)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setPadding(0, dp(18), 0, dp(6))
    }

    private fun toggleText(label: String, color: Int = -1, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 22f
        gravity = Gravity.CENTER
        setTextColor(color)
        setBackgroundColor(0)
        setPadding(dp(12), dp(4), dp(12), dp(4))
        setOnClickListener { onClick() }
    }

    private fun spinnerAdapter(items: List<String>) = object : ArrayAdapter<String>(
        this, android.R.layout.simple_spinner_item, items
    ) {
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            return (super.getView(position, convertView, parent) as TextView).apply {
                setTextColor(-1)
                textSize = 15f
                setPadding(dp(12), dp(10), dp(12), dp(10))
                setBackgroundColor(0)
            }
        }

        override fun getDropDownView(position: Int, convertView: View?, parent: ViewGroup): View {
            return (super.getDropDownView(position, convertView, parent) as TextView).apply {
                setTextColor(-1)
                textSize = 15f
                setPadding(dp(14), dp(12), dp(14), dp(12))
                setBackgroundColor(CARD)
            }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 0)
        }

        store = ProfileStore(this)
        profiles = store.load()
        if (profiles.isEmpty()) profiles.add(Profile(id = 1, name = "Server 1"))
        val activeId = store.activeId()
        activeIndex = profiles.indexOfFirst { it.id == activeId }.takeIf { it >= 0 } ?: 0

        buildUi()
        profileAdapter = spinnerAdapter(profileNames())
        profileAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        profileSpinner.adapter = profileAdapter
        profileSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?, view: View?, position: Int, id: Long
            ) {
                if (loading || position == activeIndex) return
                saveCurrent()
                if (TunnelService.running) {
                    startService(
                        Intent(this@MainActivity, TunnelService::class.java)
                            .setAction(TunnelService.ACTION_STOP)
                    )
                    Toast.makeText(
                        this@MainActivity,
                        "Tunnel diputus karena ganti profil",
                        Toast.LENGTH_SHORT
                    ).show()
                }
                activeIndex = position.coerceIn(profiles.indices)
                val p = profiles[activeIndex]
                store.save(profiles, p.id)
                loadProfile(p)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        loading = true
        profileSpinner.setSelection(activeIndex, false)
        loading = false
        loadProfile(profiles[activeIndex])

        setContentView(
            ScrollView(this).apply {
                setBackgroundColor(BG)
                isFillViewport = true
                addView(root)
            }
        )
    }

    private lateinit var root: LinearLayout

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(32))
        }
        root.addView(TextView(this).apply {
            text = "Wanz Tunnel 2.0"
            textSize = 30f
            setTextColor(-1)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        })
        root.addView(TextView(this).apply {
            text = "SSH • SOCKS5 • VPN • TLS/SNI • WebSocket"
            textSize = 14f
            setTextColor(MUTED)
        })

        btn = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 17f
            setTextColor(-1)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setOnClickListener { toggle() }
        }
        root.addView(btn, LinearLayout.LayoutParams(dp(148), dp(148)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = dp(26)
        })
        info = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 13f
            setTextColor(MUTED)
        }
        root.addView(info, lp(18))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(CARD, 24)
            setPadding(dp(16), dp(14), dp(16), dp(16))
        }

        val profileRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        profileSpinner = Spinner(this).apply {
            background = shape(FIELD, 14)
            setPadding(dp(12), 0, dp(12), 0)
        }
        profileRow.addView(profileSpinner, LinearLayout.LayoutParams(0, dp(46), 1f))
        profileRow.addView(toggleText("+", TEAL) { addProfile() }, LinearLayout.LayoutParams(-2, dp(46)).apply {
            leftMargin = dp(6)
        })
        profileRow.addView(toggleText("−", CORAL) { deleteProfile() }, LinearLayout.LayoutParams(-2, dp(46)).apply {
            leftMargin = dp(2)
        })
        card.addView(profileRow)

        card.addView(field("name", "Nama profil"), lp(10))
        val row = LinearLayout(this)
        row.addView(field("host", "IP / host server"), LinearLayout.LayoutParams(0, -2, 2f))
        row.addView(
            field("port", "Port SSH", InputType.TYPE_CLASS_NUMBER),
            LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(10) }
        )
        card.addView(row, lp(10))
        card.addView(field("user", "Username"), lp(10))
        card.addView(
            field("pass", "Password", InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD),
            lp(10)
        )
        card.addView(field("proxy", "Proxy IP:port (opsional)"), lp(10))
        card.addView(
            field("payload", "Payload, mis. CONNECT [host_port] HTTP/1.1[crlf][crlf]", lines = 3),
            lp(10)
        )

        card.addView(section("TUNNEL"))
        val socksRow = LinearLayout(this)
        socksRow.addView(
            field("socksPort", "Port SOCKS5", InputType.TYPE_CLASS_NUMBER),
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        val modeBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), 0, 0, 0)
        }
        modeSwitch = Switch(this).apply {
            setTextColor(-1)
            text = "VPN semua aplikasi"
            textSize = 13f
        }
        modeBox.addView(modeSwitch)
        socksRow.addView(modeBox, LinearLayout.LayoutParams(0, -2, 2f))
        card.addView(socksRow, lp(8))

        val transportRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        transportRow.addView(TextView(this).apply {
            text = "Transport"
            setTextColor(MUTED)
            textSize = 13f
        }, LinearLayout.LayoutParams(0, -2, 1f))
        transportSpinner = Spinner(this).apply {
            background = shape(FIELD, 14)
            adapter = spinnerAdapter(transportLabels)
        }
        transportRow.addView(transportSpinner, LinearLayout.LayoutParams(0, dp(44), 2f))
        card.addView(transportRow, lp(8))

        card.addView(field("sni", "SNI / nama host TLS (opsional)"), lp(8))
        val wsRow = LinearLayout(this)
        wsRow.addView(
            field("wsHost", "Host header WS (opsional)"),
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        wsRow.addView(
            field("wsPath", "Path WS, mis. /ssh"),
            LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(8) }
        )
        card.addView(wsRow, lp(8))

        strictSwitch = Switch(this).apply {
            setTextColor(-1)
            text = "Verifikasi sertifikat TLS ketat"
            textSize = 13f
            isChecked = true
        }
        card.addView(strictSwitch, lp(6))

        root.addView(card, lp(22))

        root.addView(TextView(this).apply {
            text = "Reset kunci host"
            textSize = 13f
            setTextColor(MUTED)
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(8))
            setOnClickListener {
                File(filesDir, "known_hosts").delete()
                Toast.makeText(this@MainActivity, "Kunci host direset", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun profileNames(): List<String> =
        profiles.map { it.name.ifBlank { "Server ${it.id}" } }

    private fun refreshProfileNames() {
        profileAdapter.clear()
        profileAdapter.addAll(profileNames())
        profileAdapter.notifyDataSetChanged()
    }

    private fun saveCurrent() {
        if (loading) return
        val p = profiles.getOrNull(activeIndex) ?: return
        p.name = text("name").ifBlank { "Server ${p.id}" }
        p.host = text("host")
        p.port = text("port").toIntOrNull()?.coerceIn(1, 65535) ?: 22
        p.user = text("user")
        p.pass = fields["pass"]?.text?.toString() ?: ""
        p.proxy = text("proxy")
        p.payload = fields["payload"]?.text?.toString() ?: ""
        p.socksPort = text("socksPort").toIntOrNull()?.coerceIn(1024, 65535) ?: 1080
        p.vpn = modeSwitch.isChecked
        p.transport = transportKeys.getOrElse(transportSpinner.selectedItemPosition) { "ssh" }
        p.sni = text("sni")
        p.wsHost = text("wsHost")
        p.wsPath = text("wsPath").ifBlank { "/" }
        p.strictTls = strictSwitch.isChecked
        store.save(profiles, p.id)
        refreshProfileNames()
    }

    private fun loadProfile(p: Profile) {
        loading = true
        fields["name"]?.setText(p.name)
        fields["host"]?.setText(p.host)
        fields["port"]?.setText(p.port.toString())
        fields["user"]?.setText(p.user)
        fields["pass"]?.setText(p.pass)
        fields["proxy"]?.setText(p.proxy)
        fields["payload"]?.setText(p.payload)
        fields["socksPort"]?.setText(p.socksPort.toString())
        modeSwitch.isChecked = p.vpn
        transportSpinner.setSelection(
            transportKeys.indexOf(p.transport).takeIf { it >= 0 } ?: 0, false
        )
        fields["sni"]?.setText(p.sni)
        fields["wsHost"]?.setText(p.wsHost)
        fields["wsPath"]?.setText(p.wsPath.ifBlank { "/" })
        strictSwitch.isChecked = p.strictTls
        loading = false
    }

    private fun addProfile() {
        saveCurrent()
        val id = (profiles.maxOfOrNull { it.id } ?: 0L) + 1
        val p = Profile(id = id, name = "Server ${profiles.size + 1}")
        profiles.add(p)
        activeIndex = profiles.size - 1
        store.save(profiles, p.id)
        loading = true
        refreshProfileNames()
        profileSpinner.setSelection(activeIndex, false)
        loading = false
        loadProfile(p)
    }

    private fun deleteProfile() {
        if (profiles.size <= 1) {
            Toast.makeText(this, "Minimal satu profil", Toast.LENGTH_SHORT).show()
            return
        }
        val p = profiles[activeIndex]
        AlertDialog.Builder(this)
            .setMessage("Hapus profil \"${p.name}\"?")
            .setNegativeButton("Batal", null)
            .setPositiveButton("Hapus") { _, _ ->
                if (TunnelService.running) {
                    startService(
                        Intent(this, TunnelService::class.java).setAction(TunnelService.ACTION_STOP)
                    )
                }
                profiles.removeAt(activeIndex)
                activeIndex = activeIndex.coerceAtMost(profiles.size - 1)
                store.save(profiles, profiles[activeIndex].id)
                loading = true
                refreshProfileNames()
                profileSpinner.setSelection(activeIndex, false)
                loading = false
                loadProfile(profiles[activeIndex])
            }
            .show()
    }

    private fun toggle() {
        val svc = Intent(this, TunnelService::class.java)
        if (TunnelService.running) {
            startService(svc.setAction(TunnelService.ACTION_STOP))
            return
        }

        saveCurrent()
        val p = profiles.getOrNull(activeIndex) ?: return
        if (p.host.isBlank()) {
            Toast.makeText(this, "Isi IP/host server dulu", Toast.LENGTH_SHORT).show()
            return
        }
        if (p.user.isBlank()) {
            Toast.makeText(this, "Isi username SSH dulu", Toast.LENGTH_SHORT).show()
            return
        }

        if (p.vpn) {
            val prepare = VpnService.prepare(this)
            if (prepare != null) {
                pendingProfileId = p.id
                startActivityForResult(prepare, REQ_VPN)
                return
            }
        }
        startTunnel(p.id)
    }

    private fun startTunnel(profileId: Long) {
        val svc = Intent(this, TunnelService::class.java)
            .setAction(TunnelService.ACTION_START)
            .putExtra(TunnelService.EXTRA_PROFILE, profileId)
        startForegroundService(svc)
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VPN) {
            if (resultCode == RESULT_OK) {
                startTunnel(pendingProfileId)
            } else {
                Toast.makeText(this, "Izin VPN ditolak", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun render() {
        val s = TunnelService.status
        val c = when {
            s.startsWith("Terhubung") -> TEAL
            s.startsWith("Gagal") -> CORAL
            else -> AMBER
        }
        btn.text = if (TunnelService.running) "Putuskan" else "Hubungkan"
        btn.background = shape(CARD, 0, c, true)
        info.text = s
    }

    override fun onResume() {
        super.onResume()
        TunnelService.onStatus = { runOnUiThread { render() } }
        render()
    }

    override fun onPause() {
        super.onPause()
        TunnelService.onStatus = null
        saveCurrent()
    }

    companion object {
        private const val REQ_VPN = 1001
    }
}
