package id.wanz.tunnel

/**
 * Palet "Neon Glass" (v2.7): latar gelap keunguan, kartu kaca,
 * aksen violet–mint. Dipakai bersama oleh semua layar.
 */
internal val BG_TOP = 0xFF08060F.toInt()
internal val BG_BOTTOM = 0xFF171122.toInt()
internal val CARD_TOP = 0x1E1D1430.toInt()
internal val CARD_BOTTOM = 0x2112101E.toInt()
internal val FIELD = 0xFF110D1C.toInt()
internal val FIELD_FOCUS = 0xFF1A1328.toInt()
internal val TEXT = 0xFFF6F1FF.toInt()
internal val MUTED = 0xFF9E93BC.toInt()

/** Aksen utama (violet). Dipakai untuk link, mode terpilih, header log. */
internal val CYAN = 0xFFA08FFF.toInt()

/** Sukses / ping (mint). */
internal val TEAL = 0xFF50F2C7.toInt()

/** Sekunder terang (ungu muda). */
internal val VIOLET = 0xFFB48CFF.toInt()

/** Peringatan / menghubungkan (amber). */
internal val AMBER = 0xFFFFC857.toInt()

/** Galat (coral). */
internal val CORAL = 0xFFFF6E7E.toInt()

internal val BORDER = 0x26FFFFFF
