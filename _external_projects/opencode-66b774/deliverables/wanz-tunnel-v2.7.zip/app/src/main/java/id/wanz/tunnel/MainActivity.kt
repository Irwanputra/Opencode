package id.wanz.tunnel

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Halaman utama "Neon Glass".
 *
 * Struktur baru:
 * - Header dengan wordmark baru (kiri) dan tombol Pengaturan (kanan).
 * - Hero: tombol koneksi baru (piringan gelap + petir) dengan status & ping.
 * - Baris statistik: kartu PING dan kartu MODE/transport bersebelahan.
 * - Kartu profil aktif, kartu log, lalu baris aksi cepat (Pengaturan /
 *   Salin log / Log penuh).
 */
class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var connectBtn: ConnectButtonView
    private lateinit var connectHint: TextView
    private lateinit var pingLine: TextView
    private lateinit var statusPill: LinearLayout
    private lateinit var statusDot: View
    private lateinit var statusText: TextView
    private lateinit var summaryName: TextView
    private lateinit var summaryDetail: TextView
    private lateinit var summaryMode: TextView
    private lateinit var statPingValue: TextView
    private lateinit var statPingSub: TextView
    private lateinit var statModeValue: TextView
    private lateinit var statModeSub: TextView
    private lateinit var logText: TextView
    private lateinit var logScroll: ScrollView

    private lateinit var store: ProfileStore
    private var profile: Profile? = null
    private var pendingProfileId = -1L
    private var logDirty = false

    private val logRenderer = Runnable {
        logDirty = false
        renderLog()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun withAlpha(color: Int, alpha: Int): Int =
        (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)

    private fun rounded(
        color: Int,
        radius: Int,
        ring: Int = 0,
        stroke: Int = 1,
        oval: Boolean = false
    ) = GradientDrawable().apply {
        if (oval) shape = GradientDrawable.OVAL else cornerRadius = dp(radius).toFloat()
        setColor(color)
        if (ring != 0) setStroke(dp(stroke), ring)
    }

    private fun lp(top: Int) =
        LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }

    private fun horizontal(gravity: Int = Gravity.CENTER_VERTICAL) =
        LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            this.gravity = gravity
        }

    private fun card(gradient: Boolean = true) = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        val bg = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            if (gradient) intArrayOf(CARD_TOP, CARD_BOTTOM)
            else intArrayOf(FIELD, FIELD)
        )
        bg.cornerRadius = dp(24).toFloat()
        bg.setStroke(dp(1), BORDER)
        background = bg
        setPadding(dp(18), dp(16), dp(18), dp(18))
        elevation = dp(2).toFloat()
    }

    private fun sectionLabel(text: String) = TextView(this).apply {
        this.text = text
        textSize = 10.5f
        letterSpacing = 0.18f
        setTextColor(withAlpha(CYAN, 225))
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    private fun iconButton(label: String, desc: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 18f
        gravity = Gravity.CENTER
        setTextColor(CYAN)
        contentDescription = desc
        setPadding(dp(12), dp(8), dp(12), dp(8))
        background = rounded(withAlpha(CYAN, 14), 99, withAlpha(CYAN, 55))
        setOnClickListener { onClick() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG_TOP
        window.navigationBarColor = BG_BOTTOM
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 0)
        }

        store = ProfileStore(this)
        buildUi()

        setContentView(ScrollView(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(BG_TOP, BG_BOTTOM)
            )
            isFillViewport = true
            clipToPadding = false
            isVerticalScrollBarEnabled = false
            addView(root, ViewGroup.LayoutParams(-1, -2))
        })

        reloadProfile()
        render()
        renderLog()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(36))
        }

        // ------------------------------------------------------------ HEADER
        val header = horizontal()
        val logo = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val logoDot = View(this)
        logoDot.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(CYAN, TEAL)
        ).apply { shape = GradientDrawable.OVAL }
        logo.addView(
            logoDot,
            LinearLayout.LayoutParams(dp(10), dp(10)).apply { rightMargin = dp(8) }
        )
        val wordmark = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        wordmark.addView(TextView(this).apply {
            text = "wanz"
            textSize = 26f
            setTextColor(TEXT)
            letterSpacing = 0.02f
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
        })
        wordmark.addView(TextView(this).apply {
            text = "TUNNEL"
            textSize = 9.5f
            setTextColor(CYAN)
            letterSpacing = 0.5f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        })
        logo.addView(wordmark)
        header.addView(logo, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(iconButton("⚙", "Buka pengaturan") {
            startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
        }, LinearLayout.LayoutParams(dp(46), dp(46)))
        root.addView(header)

        root.addView(TextView(this).apply {
            text = "SSH tunnel pribadi • mode VPN atau SOCKS5"
            textSize = 12.5f
            setTextColor(MUTED)
        }, lp(4))

        // -------------------------------------------------------------- HERO
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(24), dp(20), dp(22))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF1C1430.toInt(), 0xFF0C0918.toInt())
            ).apply {
                cornerRadius = dp(32).toFloat()
                setStroke(dp(1), withAlpha(CYAN, 55))
            }
            elevation = dp(4).toFloat()
        }
        connectBtn = ConnectButtonView(this).apply {
            contentDescription = "Hubungkan atau putuskan tunnel"
            setOnClickListener { toggle() }
        }
        hero.addView(connectBtn, LinearLayout.LayoutParams(dp(204), dp(204)))

        statusPill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        statusDot = View(this)
        statusPill.addView(
            statusDot,
            LinearLayout.LayoutParams(dp(8), dp(8)).apply { rightMargin = dp(8) }
        )
        statusText = TextView(this).apply {
            text = "Terputus"
            textSize = 13f
            setTextColor(MUTED)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        statusPill.addView(statusText)
        hero.addView(
            statusPill,
            LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(14) }
        )

        connectHint = TextView(this).apply {
            text = "Ketuk untuk menghubungkan"
            textSize = 12f
            setTextColor(MUTED)
            gravity = Gravity.CENTER
        }
        hero.addView(connectHint, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        pingLine = TextView(this).apply {
            text = "Ping: —"
            textSize = 11.5f
            setTextColor(withAlpha(TEAL, 220))
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(6), dp(12), dp(6))
            background = rounded(withAlpha(TEAL, 12), 99, withAlpha(TEAL, 40))
            setOnClickListener {
                if (TunnelService.running) {
                    startService(
                        Intent(this@MainActivity, TunnelService::class.java)
                            .setAction(TunnelService.ACTION_PING)
                    )
                } else {
                    Toast.makeText(this@MainActivity, "Hubungkan dulu untuk ping", Toast.LENGTH_SHORT)
                        .show()
                }
            }
        }
        hero.addView(
            pingLine,
            LinearLayout.LayoutParams(-2, -2).apply {
                topMargin = dp(10)
                gravity = Gravity.CENTER_HORIZONTAL
            }
        )
        root.addView(hero, lp(18))

        // ------------------------------------------------ BARIS STATISTIK
        val statsRow = horizontal()
        val pingValue = statValue()
        val pingSub = statSub()
        statPingValue = pingValue
        statPingSub = pingSub
        val modeValue = statValue()
        val modeSub = statSub()
        statModeValue = modeValue
        statModeSub = modeSub
        statsRow.addView(
            statCard("PING", pingValue, pingSub),
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        val spacer = View(this)
        statsRow.addView(spacer, LinearLayout.LayoutParams(dp(12), 1))
        statsRow.addView(
            statCard("MODE", modeValue, modeSub),
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        root.addView(statsRow, lp(14))

        // --------------------------------------------------- KARTU PROFIL
        val summaryCard = card()
        val summaryHeader = horizontal()
        summaryHeader.addView(
            sectionLabel("PROFIL AKTIF"),
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        summaryMode = TextView(this).apply {
            text = "SOCKS5"
            textSize = 10.5f
            letterSpacing = 0.06f
            setTextColor(withAlpha(CYAN, 225))
            setPadding(dp(10), dp(5), dp(10), dp(5))
            background = rounded(withAlpha(CYAN, 16), 99, withAlpha(CYAN, 60))
            setOnClickListener {
                startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
            }
        }
        summaryHeader.addView(summaryMode, LinearLayout.LayoutParams(-2, -2))
        summaryCard.addView(summaryHeader)

        summaryName = TextView(this).apply {
            text = "Server 1"
            textSize = 19f
            setTextColor(TEXT)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        summaryCard.addView(summaryName, lp(10))

        summaryDetail = TextView(this).apply {
            text = "Belum ada server"
            textSize = 12.5f
            setTextColor(MUTED)
            setLineSpacing(dp(2).toFloat(), 1f)
        }
        summaryCard.addView(summaryDetail, lp(4))

        summaryCard.addView(TextView(this).apply {
            text = "Ubah konfigurasi  →"
            textSize = 12f
            setTextColor(CYAN)
            setPadding(0, dp(12), 0, 0)
            setOnClickListener {
                startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
            }
        })
        root.addView(summaryCard, lp(14))

        // ---------------------------------------------------- KARTU LOG
        val logCard = card()
        val logHeader = horizontal()
        logHeader.addView(
            sectionLabel("LOG KONEKSI"),
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        logHeader.addView(TextView(this).apply {
            text = "Salin"
            textSize = 11f
            setTextColor(CYAN)
            setPadding(dp(4), dp(4), dp(10), dp(4))
            setOnClickListener {
                val txt = TunnelLog.snapshot().joinToString("\n")
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("WanzTunnel", txt))
                Toast.makeText(this@MainActivity, "Log disalin", Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(-2, -2))
        logHeader.addView(TextView(this).apply {
            text = "Bersihkan"
            textSize = 11f
            setTextColor(CYAN)
            setPadding(dp(10), dp(4), dp(10), dp(4))
            setOnClickListener {
                TunnelLog.clear()
                renderLog()
            }
        }, LinearLayout.LayoutParams(-2, -2))
        logHeader.addView(TextView(this).apply {
            text = "⤢"
            textSize = 14f
            setTextColor(CYAN)
            setPadding(dp(6), dp(2), dp(4), dp(4))
            contentDescription = "Buka log penuh"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, LogActivity::class.java))
            }
        }, LinearLayout.LayoutParams(-2, -2))
        logCard.addView(logHeader)

        logText = TextView(this).apply {
            text = "Menunggu aktivitas..."
            textSize = 11f
            setTextColor(withAlpha(MUTED, 235))
            typeface = Typeface.MONOSPACE
            setLineSpacing(dp(3).toFloat(), 1f)
            setTextIsSelectable(true)
        }
        logScroll = ScrollView(this).apply {
            background = rounded(FIELD, 16, BORDER)
            isFillViewport = false
            isVerticalScrollBarEnabled = true
            setPadding(dp(12), dp(12), dp(12), dp(12))
            addView(logText, ViewGroup.LayoutParams(-1, -2))
        }
        logCard.addView(logScroll, LinearLayout.LayoutParams(-1, dp(240)).apply {
            topMargin = dp(10)
        })
        root.addView(logCard, lp(14))

        // ---------------------------------------------- AKSI CEPAT
        val quick = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = rounded(0x14100E1C.toInt(), 22, BORDER)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        quick.addView(
            quickAction("⚙", "Pengaturan") {
                startActivity(Intent(this@MainActivity, SettingsActivity::class.java))
            },
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        quick.addView(
            quickAction("⧉", "Salin log") {
                val txt = TunnelLog.snapshot().joinToString("\n")
                val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("WanzTunnel", txt))
                Toast.makeText(this@MainActivity, "Log disalin", Toast.LENGTH_SHORT).show()
            },
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        quick.addView(
            quickAction("⤢", "Log penuh") {
                startActivity(Intent(this@MainActivity, LogActivity::class.java))
            },
            LinearLayout.LayoutParams(0, -2, 1f)
        )
        root.addView(quick, lp(14))

        root.addView(TextView(this).apply {
            text = "wanz tunnel • koneksi pribadi"
            textSize = 10.5f
            setTextColor(withAlpha(MUTED, 150))
            gravity = Gravity.CENTER
        }, lp(18))
    }

    private fun statCard(
        label: String,
        value: TextView,
        sub: TextView
    ): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(CARD_TOP, CARD_BOTTOM)
            ).apply {
                cornerRadius = dp(22).toFloat()
                setStroke(dp(1), BORDER)
            }
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        card.addView(TextView(this).apply {
            text = label
            textSize = 10f
            letterSpacing = 0.16f
            setTextColor(MUTED)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        })
        card.addView(value, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
        card.addView(sub, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
        return card
    }

    private fun statValue() = TextView(this).apply {
        text = "—"
        textSize = 22f
        setTextColor(TEXT)
        typeface = Typeface.create("sans-serif-bold", Typeface.NORMAL)
    }

    private fun statSub() = TextView(this).apply {
        text = ""
        textSize = 10.5f
        setTextColor(MUTED)
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
    }

    private fun quickAction(icon: String, label: String, onClick: () -> Unit) =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(4), dp(10), dp(4), dp(10))
            background = rounded(0x00FFFFFF, 18)
            isClickable = true
            setOnClickListener { onClick() }
            addView(TextView(this@MainActivity).apply {
                text = icon
                textSize = 16f
                setTextColor(CYAN)
            })
            addView(TextView(this@MainActivity).apply {
                text = label
                textSize = 10.5f
                setTextColor(MUTED)
                setPadding(0, dp(3), 0, 0)
            })
        }

    private fun reloadProfile() {
        val profiles = store.load()
        val activeId = store.activeId()
        profile = profiles.firstOrNull { it.id == activeId } ?: profiles.firstOrNull()
        renderSummary()
    }

    private fun renderSummary() {
        val p = profile
        if (p == null) {
            summaryName.text = "Server 1"
            summaryDetail.text = "Belum ada server"
            summaryMode.text = "SOCKS5"
            statModeValue.text = "SOCKS5"
            statModeSub.text = "lokal"
            return
        }
        summaryName.text = p.name.ifBlank { "Server ${p.id}" }
        val host = p.host.ifBlank { "(host belum diisi)" }
        val transport = when (p.transport) {
            "ssh" -> "SSH langsung"
            "tls" -> "TLS / SNI"
            "ws" -> "WebSocket"
            "wss" -> "WebSocket + TLS"
            else -> p.transport
        }
        summaryMode.text = if (p.vpn) "VPN" else "SOCKS5"
        summaryDetail.text = buildString {
            append("$host:${p.port}\n")
            append("Transport: $transport\n")
            append(if (p.vpn) "Mode: VPN" else "Mode: SOCKS5")
            if (p.user.isNotBlank()) append("\nUser: ${p.user}")
        }
        statModeValue.text = if (p.vpn) "VPN" else "SOCKS5"
        statModeSub.text = transport
    }

    private fun renderLog() {
        val entries = TunnelLog.all()
        logText.text = if (entries.isEmpty()) {
            "Menunggu aktivitas..."
        } else {
            renderLogSpanned(entries)
        }
        logScroll.post { logScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun toggle() {
        if (TunnelService.running) {
            startService(
                Intent(this, TunnelService::class.java).setAction(TunnelService.ACTION_STOP)
            )
            return
        }

        val p = profile ?: return
        if (p.host.isBlank()) {
            Toast.makeText(this, "Buka pengaturan lalu isi IP/host server", Toast.LENGTH_SHORT)
                .show()
            startActivity(Intent(this, SettingsActivity::class.java))
            return
        }
        if (p.user.isBlank()) {
            Toast.makeText(this, "Buka pengaturan lalu isi username SSH", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, SettingsActivity::class.java))
            return
        }

        if (p.vpn) {
            val prepare = VpnService.prepare(this)
            if (prepare != null) {
                pendingProfileId = p.id
                startActivityForResult(prepare, REQ_VPN)
                return
            }
        }
        startTunnel(p.id)
    }

    private fun startTunnel(profileId: Long) {
        val svc = Intent(this, TunnelService::class.java)
            .setAction(TunnelService.ACTION_START)
            .putExtra(TunnelService.EXTRA_PROFILE, profileId)
        startForegroundService(svc)
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_VPN) {
            if (resultCode == RESULT_OK) {
                startTunnel(pendingProfileId)
            } else {
                Toast.makeText(this, "Izin VPN ditolak", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun render() {
        val status = TunnelService.status
        val state = when {
            status.startsWith("Terhubung") -> ConnectButtonView.State.CONNECTED
            status.startsWith("Gagal") || status.startsWith("VPN dicabut") ->
                ConnectButtonView.State.ERROR
            TunnelService.running -> ConnectButtonView.State.CONNECTING
            else -> ConnectButtonView.State.IDLE
        }
        connectBtn.state = state

        val color = when (state) {
            ConnectButtonView.State.CONNECTED -> TEAL
            ConnectButtonView.State.ERROR -> CORAL
            ConnectButtonView.State.CONNECTING -> AMBER
            ConnectButtonView.State.IDLE -> MUTED
        }
        statusText.text = status
        statusText.setTextColor(if (state == ConnectButtonView.State.IDLE) MUTED else color)
        statusDot.background = rounded(color, 0, oval = true)
        statusPill.background = rounded(withAlpha(color, 24), 99, withAlpha(color, 65))
        connectHint.text = when (state) {
            ConnectButtonView.State.CONNECTED -> "Tunnel aktif • ketuk untuk memutuskan"
            ConnectButtonView.State.CONNECTING -> "Menyiapkan tunnel..."
            ConnectButtonView.State.ERROR -> "Periksa konfigurasi lalu coba lagi"
            ConnectButtonView.State.IDLE -> "Ketuk untuk menghubungkan"
        }
        connectBtn.contentDescription = when (state) {
            ConnectButtonView.State.CONNECTED -> "Putuskan tunnel"
            else -> "Hubungkan tunnel"
        }

        val ms = TunnelService.pingMs
        pingLine.text = when {
            !TunnelService.running -> "Ping: —"
            ms >= 0 -> "Ping: $ms ms  •  ketuk untuk ping ulang"
            else -> "Ping: menunggu…  •  ketuk untuk ping"
        }
        pingLine.setTextColor(
            if (TunnelService.running && ms >= 0) TEAL else withAlpha(MUTED, 220)
        )
        statPingValue.text = when {
            !TunnelService.running -> "—"
            ms >= 0 -> "$ms ms"
            else -> "…"
        }
        statPingValue.setTextColor(if (TunnelService.running && ms >= 0) TEAL else MUTED)
        statPingSub.text = when {
            !TunnelService.running -> "mati"
            ms >= 0 -> "auto ping"
            else -> "menunggu"
        }
    }

    override fun onResume() {
        super.onResume()
        TunnelService.onStatus = { runOnUiThread { render() } }
        TunnelLog.onChange = {
            if (!logDirty) {
                logDirty = true
                runOnUiThread(logRenderer)
            }
        }
        reloadProfile()
        render()
        renderLog()
    }

    override fun onPause() {
        super.onPause()
        TunnelService.onStatus = null
        TunnelLog.onChange = null
        logScroll.removeCallbacks(logRenderer)
        logDirty = false
    }

    companion object {
        private const val REQ_VPN = 1001
    }
}
