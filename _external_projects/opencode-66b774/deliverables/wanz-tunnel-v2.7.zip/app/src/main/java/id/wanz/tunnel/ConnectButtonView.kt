package id.wanz.tunnel

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.view.View
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin

/**
 * Tombol koneksi "Neon Glass": piringan gelap, cincin gradien violet–mint,
 * ikon petir, dan denyut glow sesuai status.
 */
class ConnectButtonView(context: Context) : View(context) {
    enum class State { IDLE, CONNECTING, CONNECTED, ERROR }

    var state: State = State.IDLE
        set(value) {
            if (field == value) return
            field = value
            updateAnimation()
            invalidate()
        }

    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = dp(2.6f)
        strokeCap = Paint.Cap.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val boltPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val boltCorePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val boltPath = Path()

    private var phase = 0f
    private var animator: ValueAnimator? = null

    private val accent: Int
        get() = when (state) {
            State.CONNECTED -> TEAL
            State.ERROR -> CORAL
            State.CONNECTING -> AMBER
            else -> CYAN
        }

    private val accent2: Int
        get() = when (state) {
            State.ERROR -> 0xFFFF9A6B.toInt()
            State.CONNECTED -> 0xFF8B7CFF.toInt()
            else -> 0xFF50F2C7.toInt()
        }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val maxR = min(width, height) / 2f - dp(8f)
        val innerR = maxR - dp(24f)
        val pulse = 0.5f + 0.5f * sin(phase * 2.0 * PI).toFloat()

        // Glow luar (hanya saat aktif / sibuk).
        if (state == State.CONNECTING || state == State.CONNECTED) {
            glowPaint.color = withAlpha(accent, (16 + 26 * pulse).toInt())
            canvas.drawCircle(cx, cy, maxR, glowPaint)
        }

        // Cincin gradien.
        ringPaint.shader = SweepGradient(
            cx, cy,
            intArrayOf(withAlpha(accent, 40), accent, accent2, withAlpha(accent, 40)),
            floatArrayOf(0f, 0.32f, 0.7f, 1f)
        )
        ringPaint.strokeWidth = dp(2.6f)
        canvas.save()
        if (state == State.CONNECTING) canvas.rotate(phase * 360f, cx, cy)
        canvas.drawCircle(cx, cy, maxR - dp(6f), ringPaint)
        canvas.restore()

        // Piringan gelap kaca.
        fillPaint.shader = RadialGradient(
            cx, cy - innerR * 0.35f, innerR * 1.55f,
            intArrayOf(
                withAlpha(accent, 45),
                0xFF1B1430.toInt(),
                0xFF0B0916.toInt()
            ),
            floatArrayOf(0f, 0.55f, 1f),
            Shader.TileMode.CLAMP
        )
        canvas.drawCircle(cx, cy, innerR, fillPaint)

        ringPaint.shader = null
        ringPaint.color = withAlpha(accent, 90)
        ringPaint.strokeWidth = dp(1f)
        canvas.drawCircle(cx, cy, innerR, ringPaint)

        // Cincin dalam tipis dengan jeda (gaya "orb").
        ringPaint.color = withAlpha(accent, 45)
        ringPaint.strokeWidth = dp(0.8f)
        canvas.drawArc(
            RectF(cx - innerR * 0.72f, cy - innerR * 0.72f, cx + innerR * 0.72f, cy + innerR * 0.72f),
            0f, 300f, false, ringPaint
        )

        // Ikon petir.
        drawBolt(canvas, cx, cy, innerR * 0.52f, accent)
    }

    private fun drawBolt(canvas: Canvas, cx: Float, cy: Float, r: Float, color: Int) {
        boltPath.reset()
        // Petir di ruang satuan (pusat 0,0).
        boltPath.moveTo(-0.30f * r, -r)
        boltPath.lineTo(0.20f * r, -0.12f * r)
        boltPath.lineTo(0.00f * r, -0.12f * r)
        boltPath.lineTo(0.30f * r, r)
        boltPath.lineTo(-0.20f * r, 0.14f * r)
        boltPath.lineTo(0.00f * r, 0.14f * r)
        boltPath.close()
        boltPath.offset(cx, cy)

        boltCorePaint.color = withAlpha(0xFFFDF6FF.toInt(), 210)
        boltPaint.color = color
        canvas.drawPath(boltPath, boltPaint)
        // Sorot lebih terang di sisi kiri (efek kedalaman).
        val shine = Path(boltPath)
        canvas.save()
        canvas.clipPath(boltPath)
        shine.offset(-r * 0.08f, -r * 0.06f)
        boltCorePaint.color = withAlpha(color, 90)
        canvas.drawPath(shine, boltCorePaint)
        canvas.restore()
    }

    private fun updateAnimation() {
        if (state == State.CONNECTING || state == State.CONNECTED) {
            if (animator == null) {
                animator = ValueAnimator.ofFloat(0f, 1f).apply {
                    duration = 2200L
                    repeatCount = ValueAnimator.INFINITE
                    addUpdateListener {
                        phase = it.animatedValue as Float
                        invalidate()
                    }
                    start()
                }
            }
        } else {
            animator?.cancel()
            animator = null
            phase = 0f
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        animator = null
        super.onDetachedFromWindow()
    }

    private fun withAlpha(color: Int, alpha: Int): Int =
        (color and 0x00FFFFFF) or (alpha.coerceIn(0, 255) shl 24)
}
